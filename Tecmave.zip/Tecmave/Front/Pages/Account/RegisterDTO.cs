﻿namespace Front.Pages.Account
{
    public class RegisterDTO
    {

        public string Email {  get; set; }

        public string Password { get; set; }

        public string Password2 { get; set; }

        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Cedula { get; set; }
        public string Direccion { get; set; }
        public string PhoneNumber { get; set; }

    }
}
