using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Front.Pages.Vehiculos
{
    public class CrearModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
